// API key
const API_KEY = "pk.eyJ1IjoibWFyaWxveWhqIiwiYSI6ImNsNHJuaWo1aDB3azYza3M4d3R2aXBsNGEifQ.UbIRzLAYpergeRd2_L4ceA";
